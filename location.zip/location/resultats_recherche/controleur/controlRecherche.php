<?php
	/**
	* 
	*/
	class SearchResult
	{
		//private $motCle;

		public function Recherche($motCle) {
			if (isset($motCle)&&!empty($motCle)) {
				die("ok");
			} else {
				# code...
			}
			
		}
		
		function __construct()
		{
			# code...
		}
	}
?>