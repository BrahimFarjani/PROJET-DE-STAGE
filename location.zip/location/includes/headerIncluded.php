<div class="container rmUnderline header">
	<div class="row">
		<div class="col-xs-12">
			<table width="100%">
				<tr>
					<td width="300">
						<div>
							<a href="./">
								<i class="fa fa-home fa-2x"> </i>
								Accueil
							</a>
						</div>
					</td>
					<td class="celSearch">
						<form id="search">
							<div class="input-group">
								<input type="text" name="motCle" id="motCle" class="form-control" placeholder="Rechercher un véhicule ..." />
								<span class="input-group-btn">
									<button type="submit" class="btn btn-danger" style="width: 60px;">
										<span class="glyphicon glyphicon-search"></span>
									</button>
								</span>
							</div>
						</form>
					</td>
					<td>
						
					</td>
					<td align="right" class="contact_a_propos">
						<a href="#">
							<i class="fa fa-phone"> </i> Contacts
						</a> |
						<a href="#">
							<i class="fa fa-info-circle"> </i> A propos
						</a>
					</td>
					<td></td>
				</tr>
			</table>
		</div>
	</div>
</div>

<div class="middleBar rmUnderline">
	<table width="100%">
		<tr>
			<td width="200">
				<i class="fa fa-car fa-2x"> </i>
				CarsLocation
			</td>
			<td align="right" class="slogan">
				<a href="#" style="color: #fff;">
					<i class="fa fa-question-circle"> </i>
					Obtenir de l'aide
				</a>
			</td>
		</tr>
	</table>
</div>