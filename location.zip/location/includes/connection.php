<?php
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!defined('DB_HOST')) {
        define('DB_HOST', '127.0.0.1');
    }
    if (!defined('DB_NAME')) {
        define('DB_NAME', 'location_vehicule');
    }
    if (!defined('DB_USER')) {
        define('DB_USER', 'root');
    }
    if (!defined('DB_PASSWORD')) {
        define('DB_PASSWORD', '');
    }
    
    try {
        $bdd = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
    } catch(PDOException $e) {
        die('Une erreur est survenue lors de la connexion a la base de données');
    }
?>
