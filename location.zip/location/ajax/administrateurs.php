<center>
	<h3><i class="fa fa-users"> </i> Gestion d'administrateurs</h3>
	<div style="border: 1px solid #aaa; margin-right: 40px;"></div>
</center><br />